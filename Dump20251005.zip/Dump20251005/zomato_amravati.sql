-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `amravati`
--

DROP TABLE IF EXISTS `amravati`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `amravati` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` double DEFAULT NULL,
  `VOTES` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amravati`
--

LOCK TABLES `amravati` WRITE;
/*!40000 ALTER TABLE `amravati` DISABLE KEYS */;
INSERT INTO `amravati` VALUES ('Jazeerah Restaurant',400,'Malwani,Modern Indian,Roast Chicken,Seafood','Amravati','Ambapeth','https://www.zomato.com/amravati/jazeerah-restaurant-ambapeth/info',1,'Casual Dining','11am to 12midnight(Mon-Sun)','Very Good',4.2,26),('Hotel Up & Above',200,'North Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/hotel-up-above-maltekedi/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Excellent',4.6,31),('New Punjabi Dhaba & Restaurant',200,'Indian,North Indian,Maharashtrian','Amravati','Ambapeth','https://www.zomato.com/amravati/new-punjabi-dhaba-restaurant-ambapeth/info',1,'Quick Bites','1130am to 11pm(Mon-Sun)','Very Good',4.1,14),('New Eagle Restaurant',200,'North Indian','Amravati','Nai Basti','https://www.zomato.com/amravati/new-eagle-restaurant-nai-basti/info',1,'Casual Dining','930am to 11pm(Mon-Sun)','Excellent',4.5,25),('South Kitchen',500,'North Indian,South Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/south-kitchen-maltekedi/info',1,'Casual Dining','630am to 1030pm(Mon-Sun)','Very Good',4,8),('Al Basheer Restaurant',200,'North Indian','Amravati','Nai Basti','https://www.zomato.com/amravati/al-basheer-restaurant-nai-basti/info',1,'Casual Dining','9am to 11pm(Mon-Sun)','Good',3.7,21),('Bombay Street Cafe',300,'Fast Food','Amravati','Ambapeth','https://www.zomato.com/amravati/bombay-street-cafe-ambapeth/info',1,'Casual Dining','8am to 11pm(Mon-Sun)','Good',3.8,9),('Manvaar - The Indian Restaurant',300,'Juices,Modern Indian','Amravati','Ambapeth','https://www.zomato.com/amravati/manvaar-the-indian-restaurant-ambapeth/info',1,'Quick Bites','11am to 11pm(Mon-Sun)','Good',3.7,8),('Goli Vada Pav No- 1',100,'Maharashtrian','Amravati','Arjun Nagar','https://www.zomato.com/amravati/goli-vada-pav-no-1-arjun-nagar/info',1,'Quick Bites','10am to 11pm(Mon-Sun)','Good',3.9,11),('Cafe Eatalious',200,'Pizza,Sandwich,Burger,Rolls,Chinese,Beverages','Amravati','Sai Nagar','https://www.zomato.com/amravati/cafe-eatalious-sai-nagar/info',1,'none','10am to 11pm(Mon-Sun)','Very Good',4.1,14),('Mamaji Restaurant',200,'North Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/mamaji-restaurant-maltekedi/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.1,11),('Foodbux Cafe',200,'Pizza,Burger,Sandwich','Amravati','Maltekedi','https://www.zomato.com/amravati/foodbux-cafe-maltekedi/info',1,'CafÃ©','11am to 11pm(Mon-Sun)','Very Good',4,8),('Taste Of South',500,'North Indian,South Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/taste-of-south-maltekedi/info',1,'Casual Dining','8am to 11pm(Mon-Sun)','Good',3.5,10),('Heritage Kitchen Restaurant & Celebration Hall',300,'North Indian','Amravati','Navsaari','https://www.zomato.com/amravati/heritage-kitchen-restaurant-celebration-hall-navsaari/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.4,9),('Raai Jeera Veg & Desi Restaurant',250,'North Indian','Amravati','Ambapeth','https://www.zomato.com/amravati/raai-jeera-veg-desi-restaurant-ambapeth/info',2,'Casual Dining','11am to 11pm(Mon-Sun)','Good',3.6,6),('Santosh Bhuwan',100,'North Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/santosh-bhuwan-maltekedi/info',2,'Quick Bites','8am to 11pm(Mon-Sun)','Good',3.6,5),('Kanhaiya Kunj',200,'Indian','Amravati','Sai Nagar','https://www.zomato.com/amravati/kanhaiya-kunj-sai-nagar/info',2,'none','10am to 11pm(Mon-Sun)','Very Good',4.1,6),('manmohan family restaurant',200,'South Indian,North Indian,Maharashtrian,Indian,Fast Food,Chinese','Amravati','Maltekedi','https://www.zomato.com/amravati/manmohan-family-restaurant-maltekedi/info',2,'Fine Dining','11am to 1030pm(Mon-Sun)','Average',3.1,9),('Chaat Bazaar',300,'Burger,Chinese,Fast Food,Healthy Food,Ice Cream,North Indian,Sandwich,South Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/chaat-bazaar-maltekedi/info',2,'Dessert Parlor','1230pm to 11pm(Mon-Sun)','Good',3.9,6),('Goli Vada Pav No-1',200,'Sandwich,Fast Food,Maharashtrian','Amravati','Sharda Vihar','https://www.zomato.com/amravati/goli-vada-pav-no-1-sharda-vihar/info',2,'Quick Bites','10am to 11pm(Mon-Sun)','Good',3.8,9),('Marasim Restaurant',300,'Biryani,Seafood,Malwani','Amravati','Hazrat Bilal Nagar','https://www.zomato.com/amravati/marasim-restaurant-hazrat-bilal-nagar/info',2,'Quick Bites','11am to 11pm(Mon-Sun)','Good',3.9,8),('Sahuji Ka Dhaba',200,'North Indian','Amravati','Ambapeth','https://www.zomato.com/amravati/sahuji-ka-dhaba-ambapeth/info',2,'Casual Dining','1130am to 10pm(Mon-Sun)','Very Good',4,10),('Hotel Abdullah',200,'Biryani,North Indian,Seafood,Chinese','Amravati','Ambapeth','https://www.zomato.com/amravati/hotel-abdullah-ambapeth/info',2,'Casual Dining','930am to 630pm(Mon-Sat),Closed(Sun)','Excellent',4.7,10),('Spru\'s Pizza Cafe',200,'Pizza,Sandwich,Burger','Amravati','Sai Nagar','https://www.zomato.com/amravati/sprus-pizza-cafe-sai-nagar/info',2,'none','2pm to 11pm(Mon-Sun)','Good',3.7,7),('New Kolkata Rolls',100,'Rolls','Amravati','Navsaari','https://www.zomato.com/amravati/new-kolkata-rolls-navsaari/info',2,'Food Court','12noon to 1030pm(Mon-Sun)','Good',3.9,5),('D\' Barbeque a Unit of Warhadi Thath',200,'North Indian','Amravati','Ambapeth','https://www.zomato.com/amravati/d-barbeque-a-unit-of-warhadi-thath-ambapeth/info',2,'Quick Bites','12noon to 11pm(Mon-Sun)','Good',3.8,5),('SAI Chinese & Fast Food',150,'Chinese,Fast Food','Amravati','Hazrat Bilal Nagar','https://www.zomato.com/amravati/sai-chinese-fast-food-hazrat-bilal-nagar/info',2,'Quick Bites','(Mon-Sun)','Good',3.9,7),('Kazim\'s Pizza & Tandoor',200,'North Indian','Amravati','Transport Nagar','https://www.zomato.com/amravati/kazims-pizza-tandoor-transport-nagar/info',2,'Quick Bites','6pm to 11pm(Mon-Sun)','Good',3.8,8),('Purnabhramha',400,'North Indian,Maharashtrian','Amravati','Ambapeth','https://www.zomato.com/amravati/purnabhramha-ambapeth/info',2,'Quick Bites','(Mon-Sun)','Good',3.6,6),('BARBEQUE - N',300,'North Indian,Maharashtrian,Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/barbeque-n-maltekedi/info',3,'Fine Dining','11am to 11pm(Mon-Sun)','Good',3.5,4),('Spice Kitchen',200,'North Indian','Amravati','Maltekedi','https://www.zomato.com/amravati/spice-kitchen-maltekedi/info',3,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.2,5),('Delhi Paratha House',200,'North Indian','Amravati','Sharda Vihar','https://www.zomato.com/amravati/delhi-paratha-house-sharda-vihar/info',3,'Quick Bites','(Mon-Sun)','Good',3.6,4),('Shivshakti Icecream and Juice',100,'Juices,Ice Cream','Amravati','Ambapeth','https://www.zomato.com/amravati/shivshakti-icecream-and-juice-ambapeth/info',3,'Beverage Shop','(Mon-Sun)','Good',3.5,4),('The Mini Punjab',500,'Indian,Maharashtrian','Amravati','Maltekedi','https://www.zomato.com/amravati/the-mini-punjab-maltekedi/info',3,'Casual Dining','11am to 11pm(Mon-Sun)','Good',3.5,4),('Nescafe',300,'Bakery,Cafe,Chinese,Coffee,Fast Food,Healthy Food,Indian,Pizza','Amravati','Maltekedi','https://www.zomato.com/amravati/nescafe-maltekedi/info',3,'CafÃ©','6am to 9pm,11pm to 1130pm,10pm to 1030pm...','Average',3.4,5),('Sukh Sagar Fast Food And Restaurant',300,'North Indian','Amravati','Ambapeth','https://www.zomato.com/amravati/sukh-sagar-fast-food-and-restaurant-ambapeth/info',4,'Casual Dining','930am to 10pm(Mon-Sun)','Average',3,4),('Panino The Sandwich World',200,'Burger,Fast Food,Cafe,Sandwich','Amravati','Ambapeth','https://www.zomato.com/amravati/panino-the-sandwich-world-ambapeth/info',4,'Casual Dining','12noon to 11pm(Mon-Sun)','Good',3.7,4),('Khamaz The House Of Biryani',300,'Biryani,Roast Chicken','Amravati','Maltekedi','https://www.zomato.com/amravati/khamaz-the-house-of-biryani-maltekedi/info',5,'Casual Dining','6pm to 11pm(Mon-Sun)','Good',3.8,4),('Hotel Iccha',500,'North Indian','Amravati','Sharda Vihar','https://www.zomato.com/amravati/hotel-iccha-sharda-vihar/info',6,'Casual Dining','10am to 11pm(Mon-Sun)','Good',3.6,5),('Biryani House',200,'Biryani','Amravati','Navsaari','https://www.zomato.com/amravati/biryani-house-navsaari/info',6,'Casual Dining','4pm to 11pm(Mon-Sun)','Average',3.2,4),('Mohini\'s Food Square',250,'North Indian,Chinese','Amravati','Navsaari','https://www.zomato.com/amravati/mohinis-food-square-navsaari/info',6,'Casual Dining','12noon to 11pm(Mon-Sun)','Good',3.5,4),('Hotel Mezbaan',200,'North Indian,Maharashtrian,Indian,Chinese','Amravati','Maltekedi','https://www.zomato.com/amravati/hotel-mezbaan-maltekedi/info',6,'Fine Dining','4pm to 11pm(Mon-Sun)','Average',3.1,4),('Mauli Restaurant',600,'North Indian,Chinese','Amravati','Dastur Nagar','https://www.zomato.com/amravati/mauli-restaurant-dastur-nagar/info',7,'Casual Dining','11am to 1030pm(Mon),11am to 11pm(Tue-Sun)','Average',3.4,4),('Purple Wok Co',250,'Chinese,Juices,Momos','Amravati','Maltekedi','https://www.zomato.com/amravati/purple-wok-co-maltekedi/info',7,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.4,4);
/*!40000 ALTER TABLE `amravati` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:19
