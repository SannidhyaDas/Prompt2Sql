-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rishikesh`
--

DROP TABLE IF EXISTS `rishikesh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rishikesh` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` double DEFAULT NULL,
  `VOTES` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rishikesh`
--

LOCK TABLES `rishikesh` WRITE;
/*!40000 ALTER TABLE `rishikesh` DISABLE KEYS */;
INSERT INTO `rishikesh` VALUES ('Domino\'s Pizza',400,'Pizza,Fast Food','Rishikesh','Manvendera Nagar','https://www.zomato.com/rishikesh/dominos-pizza-manvendera-nagar/info',1,'Quick Bites','11am to 11pm(Mon-Sun)','Average',3.4,227),('Cafe Karma',450,'Cafe','Rishikesh','Tapovan','https://www.zomato.com/rishikesh/cafe-karma-tapovan/info',1,'CafÃ©','7am to 11pm(Mon-Sun)','Average',3.4,44),('Frost Factory',200,'Ice Cream,Desserts','Rishikesh','Tapovan','https://www.zomato.com/rishikesh/frost-factory-tapovan/info',1,'Dessert Parlor','10am to 12midnight(Mon-Sun)','Average',3.3,23),('Tip Top Restaurant',600,'North Indian,Chinese','Rishikesh','Tapovan','https://www.zomato.com/rishikesh/tip-top-restaurant-tapovan/info',1,'Casual Dining','8am to 12midnight(Mon-Sun)','Average',3.3,25),('Chotiwala',500,'North Indian','Rishikesh','Swarg Ashram','https://www.zomato.com/rishikesh/chotiwala-3-swarg-ashram/info',1,'Casual Dining','8am to 10pm(Mon-Sun)','Average',3.2,92),('Food Grage',400,'North Indian,Chinese','Rishikesh','Tapovan','https://www.zomato.com/rishikesh/food-grage-tapovan/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.3,11),('Dilli Bites',600,'North Indian,Italian,Chinese','Rishikesh','Tapovan','https://www.zomato.com/rishikesh/dilli-bites-tapovan/info',1,'Casual Dining','8am to 10pm(Mon-Sun)','Average',3.2,16),('Negi Restaurant & Cafe',400,'North Indian,Chinese','Rishikesh','Tapovan','https://www.zomato.com/rishikesh/negi-restaurant-cafe-tapovan/info',1,'Quick Bites','7am to 1030pm(Mon-Sun)','Average',3.2,11);
/*!40000 ALTER TABLE `rishikesh` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:08
