-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ooty`
--

DROP TABLE IF EXISTS `ooty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ooty` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` double DEFAULT NULL,
  `VOTES` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ooty`
--

LOCK TABLES `ooty` WRITE;
/*!40000 ALTER TABLE `ooty` DISABLE KEYS */;
INSERT INTO `ooty` VALUES ('Angaara',1000,'Arabian,Chinese,Continental,South Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/angaara-elk-hill/info',1,'Casual Dining','1130am to 1130pm(Mon-Sun)','Good',3.6,144),('Domino\'s Pizza',500,'Pizza,Fast Food','Ooty','Elk Hill','https://www.zomato.com/ooty/dominos-pizza-elk-hill/info',1,'Quick Bites','11am to 12midnight(Mon-Sun)','Average',3.3,75),('Pankaj Bhojanalaya',400,'North Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/pankaj-bhojanalaya-elk-hill/info',1,'Quick Bites','9am to 11pm(Mon-Sun)','Average',3.3,23),('A2B- Adyar Ananda Bhavan',300,'South Indian,North Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/a2b-adyar-ananda-bhavan-elk-hill/info',1,'Casual Dining','730am to 1030pm(Mon-Sun)','Average',3.4,139),('Hyderabad Biriyani House',500,'Andhra,Biryani','Ooty','Kandal','https://www.zomato.com/ooty/hyderabad-biriyani-house-kandal/info',1,'Casual Dining','11am to 1030pm(Mon-Sun)','Average',3.3,39),('Cocoapods',450,'Cafe','Ooty','Kandal','https://www.zomato.com/ooty/cocoapods-kandal/info',1,'CafÃ©','1030am to 930pm(Mon-Sun)','Average',3.3,24),('Willy\'s Coffee Pub',350,'Cafe','Ooty','Elk Hill','https://www.zomato.com/ooty/willys-coffee-pub-elk-hill/info',1,'CafÃ©','10am to 930pm(Mon-Sun)','Average',3.3,39),('Thalassery Restaurant',600,'South Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/thalassery-restaurant-elk-hill/info',1,'Casual Dining','8am to 1030pm(Mon-Sun)','Average',3.3,42),('Darjeeling Spicy Momo',250,'Chinese,Tibetan,Momos','Ooty','Elk Hill','https://www.zomato.com/ooty/darjeeling-spicy-momo-elk-hill/info',1,'Kiosk','2pm to 930pm(Mon-Sun)','Average',3.4,20),('New Ooty Bakery',300,'Mithai,Bakery,Chinese,Fast Food','Ooty','Elk Hill','https://www.zomato.com/ooty/new-ooty-bakery-elk-hill/info',1,'Bakery','830am to 9pm(Mon-Sun)','Average',3.3,22),('Kabab Corner',600,'Chinese,North Indian,Biryani','Ooty','Kandal','https://www.zomato.com/ooty/kabab-corner-kandal/info',1,'Casual Dining','1230pm to 11pm(Mon-Sun)','Average',3.2,11),('Quality Restaurant',650,'Chinese,South Indian,North Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/quality-restaurant-elk-hill/info',1,'Casual Dining','1030am to 1030pm(Mon-Sun)','Average',3.2,15),('Hotel Junior Kuppanna',400,'Chettinad,South Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/hotel-junior-kuppanna-elk-hill/info',1,'Casual Dining','830am to 430pm,630pm to 10pm(Mon-Sun)','Average',3.3,20),('Syedi Restaurant',250,'North Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/syedi-restaurant-1-elk-hill/info',1,'Quick Bites','(Mon-Sun)','Average',3.4,9),('Thendral Restaurant',450,'South Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/thendral-restaurant-elk-hill/info',1,'Casual Dining','730am to 10pm(Mon-Sun)','Average',3.4,7),('Cliff Top',800,'North Indian,South Indian,European','Ooty','Kandal','https://www.zomato.com/ooty/cliff-top-kandal/info',2,'Casual Dining','8am to 10am,730pm to 1030pm,1230pm to 3pm...','Average',3.3,10),('LaakDe CafÃ©',400,'Cafe,Bakery','Ooty','Elk Hill','https://www.zomato.com/ooty/laakde-cafÃ©-elk-hill/info',2,'CafÃ©','8am to 9pm(Mon-Sun)','Average',3.3,14),('Hotel Coonoor Ramachandra',500,'South Indian,North Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/hotel-coonoor-ramachandra-elk-hill/info',2,'Casual Dining','8am to 9pm(Mon-Sun)','Average',3.3,8),('KE\'s Restaurant',600,'North Indian,South Indian','Ooty','Kandal','https://www.zomato.com/ooty/kes-restaurant-kandal/info',2,'Casual Dining','8am to 11pm(Mon-Sun)','Average',3.2,28),('Turntable',650,'Chinese,North Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/turntable-elk-hill/info',2,'Casual Dining','8am to 10pm(Mon-Sun)','Average',3.4,18),('Lemongrass Restaurant',600,'Chinese,North Indian,South Indian','Ooty','Kandal','https://www.zomato.com/ooty/lemongrass-restaurant-kandal/info',2,'Casual Dining','8am to 10am,730pm to 1030pm,12noon to 3pm...','Average',3.2,6),('ibaco',200,'Ice Cream','Ooty','Marlimund','https://www.zomato.com/ooty/ibaco-marlimund/info',2,'Dessert Parlor','10am to 10pm(Mon-Sun)','Average',3.2,6),('Green Nasco Food Court',200,'Fast Food,North Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/green-nasco-food-court-elk-hill/info',2,'Food Court','(Mon-Sun)','Average',3.2,4),('Deliceiux',100,'Bakery','Ooty','Elk Hill','https://www.zomato.com/ooty/deliceiux-elk-hill/info',2,'Bakery','9am to 1030pm(Mon-Sun)','Average',3.2,5),('Madras Rasoi',350,'Biryani,Chinese,South Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/madras-rasoi-elk-hill/info',2,'Casual Dining','8am to 11pm(Mon-Sun)','Average',3.2,13),('Hotel Blue Hills',300,'North Indian,South Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/hotel-blue-hills-elk-hill/info',3,'Casual Dining','1230pm to 11pm(Mon-Sun)','Average',3.3,17),('Hotel Taj',500,'Chinese,North Indian,South Indian','Ooty','Elk Hill','https://www.zomato.com/ooty/hotel-taj-elk-hill/info',3,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.2,5);
/*!40000 ALTER TABLE `ooty` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:19
