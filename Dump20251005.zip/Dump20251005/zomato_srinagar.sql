-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `srinagar`
--

DROP TABLE IF EXISTS `srinagar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `srinagar` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` double DEFAULT NULL,
  `VOTES` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `srinagar`
--

LOCK TABLES `srinagar` WRITE;
/*!40000 ALTER TABLE `srinagar` DISABLE KEYS */;
INSERT INTO `srinagar` VALUES ('Ahdoo\'s',700,'South Indian,North Indian,Kashmiri','Srinagar','Lal Chowk','https://www.zomato.com/srinagar/ahdoos-lal-chowk/info',1,'Casual Dining','10am to 1030pm(Mon-Sun)','Good',3.6,108),('Fat Panda',400,'Chinese','Srinagar','Dal Gate','https://www.zomato.com/srinagar/fat-panda-dal-gate/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.2,27),('Mummy Please',500,'Fast Food,Italian','Srinagar','Lal Chowk','https://www.zomato.com/srinagar/mummy-please-lal-chowk/info',1,'Quick Bites','10am to 930pm(Mon-Sun)','Average',3.3,96),('Hungerhook The Pizza Shop',500,'Pizza','Srinagar','Nowgam','https://www.zomato.com/srinagar/hungerhook-the-pizza-shop-nowgam/info',1,'Quick Bites','10am to 10pm(Mon-Sun)','Average',3.3,76),('Mummy Please Express',500,'Pizza,Fast Food','Srinagar','Lal Chowk','https://www.zomato.com/srinagar/mummy-please-express-lal-chowk/info',1,'Quick Bites','1130am to 830pm(Mon-Sun)','Average',3.3,42),('Cafe De Polo',800,'South Indian,North Indian,Chinese,Italian','Srinagar','Lal Chowk','https://www.zomato.com/srinagar/cafe-de-polo-lal-chowk/info',1,'Casual Dining','10am to 10pm(Mon-Sun)','Average',3.2,18),('High Street Restaurant and Cafe',400,'Kashmiri,Mughlai,Afghan','Srinagar','Lal Bazaar','https://www.zomato.com/srinagar/high-street-restaurant-and-cafe-lal-bazaar/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Average',3.2,12),('Hat Trick Pizza Hut',400,'Pizza','Srinagar','Srinagar','https://www.zomato.com/srinagar/hat-trick-pizza-hut-srinagar/info',1,'Quick Bites','10am to 10pm(Mon-Sun)','Average',3.2,28),('Kooks',600,'Fast Food,Italian','Srinagar','Chinar Bagh','https://www.zomato.com/srinagar/kooks-chinar-bagh/info',1,'Quick Bites','10am to 10pm(Mon-Sun)','Average',3.2,11),('Delhi Di Rasoi',400,'Street Food,North Indian,South Indian','Srinagar','Dal Gate','https://www.zomato.com/srinagar/delhi-di-rasoi-1-dal-gate/info',1,'Casual Dining','11am to 930pm(Mon-Sun)','Average',3.2,7),('Boulevard Avenue Dine In',800,'Chinese,North Indian','Srinagar','Dal Gate','https://www.zomato.com/srinagar/boulevard-avenue-dine-in-dal-gate/info',1,'Casual Dining','11am to 830pm(Mon-Sun)','Average',3.2,7),('Bangs',400,'Fast Food,Burger','Srinagar','Lal Bazaar','https://www.zomato.com/srinagar/bangs-lal-bazaar/info',1,'Quick Bites','11am to 9pm(Mon-Sun)','Average',3.2,4);
/*!40000 ALTER TABLE `srinagar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:13
