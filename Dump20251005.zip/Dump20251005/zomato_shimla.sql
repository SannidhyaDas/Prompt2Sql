-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `shimla`
--

DROP TABLE IF EXISTS `shimla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shimla` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` text,
  `VOTES` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shimla`
--

LOCK TABLES `shimla` WRITE;
/*!40000 ALTER TABLE `shimla` DISABLE KEYS */;
INSERT INTO `shimla` VALUES ('Domino\'s',450,'Pizza','Shimla','Summer Hill','https://www.zomato.com/shimla/dominos-summer-hill/info',1,'none','10am to 12midnight(Mon-Sun)','Good','3.5','120'),('Singh\'s Tandoor',450,'North Indian,Fast Food','Shimla','Sanjauli','https://www.zomato.com/shimla/singhs-tandoor-sanjauli/info',1,'Quick Bites','10am to 1030pm(Mon-Sun)','Average','3.3','48'),('The EBR Cafe',500,'Mexican,Italian,Cafe','Shimla','Summer Hill','https://www.zomato.com/shimla/the-ebr-cafe-summer-hill/info',1,'CafÃ©','10am to 9pm(Mon-Sun)','Average','3.2','15'),('Que Cafe',500,'Cafe,Italian','Shimla','Kasumpti','https://www.zomato.com/shimla/que-cafe-kasumpti/info',1,'CafÃ©','10am to 1130pm(Mon-Sun)','Average','3.3','32'),('Kennedy House',1400,'Italian,Chinese,North Indian','Shimla','Mashobra','https://www.zomato.com/shimla/kennedy-house-mashobra/info',1,'Lounge','730am to 1030pm(Mon-Sun)','Not rated','-','-'),('New Diamond Restaurant',500,'Bakery,North Indian,Chinese,South Indian,Fast Food','Shimla','Sanjauli','https://www.zomato.com/shimla/new-diamond-restaurant-sanjauli/info',1,'Bakery','8am to 1030pm(Mon-Sun)','','NEW','NEW'),('City Point',0,'North Indian,Italian,Continental,Cafe,Burger','Shimla','Sanjauli','https://www.zomato.com/shimla/city-point-sanjauli/info',1,'CafÃ©','11am to 930pm(Mon-Sun)','','NEW','NEW'),('Tea Bliss',1500,'Asian','Shimla','Mashobra','https://www.zomato.com/shimla/tea-bliss-mashobra/info',1,'Lounge','1230pm to 1030pm(Mon-Sun)','Not rated','-','-'),('Lekh Raj fast food',200,'North Indian','Shimla','Summer Hill','https://www.zomato.com/shimla/lekh-raj-fast-food-summer-hill/info',1,'Quick Bites','11am to 4pm(Mon-Sun)','Average','3.2','4'),('DX Fast Food',0,'Burger,Chinese','Shimla','Sanjauli','https://www.zomato.com/shimla/dx-fast-food-sanjauli/info',1,'Beverage Shop','1030am to 10pm(Mon-Sun)','','NEW','NEW'),('Republic of Chicken',0,'Afghan,Asian,BBQ,Chinese,Fast Food,Finger Food,Healthy Food,Himachali','Shimla','Panthaghati','https://www.zomato.com/shimla/republic-of-chicken-panthaghati/info',1,'Meat Shop','11am to 9pm(Mon-Sun)','','NEW','NEW'),('RK Chinese Fast Food',100,'Chinese,Desserts,Fast Food','Shimla','Sanjauli','https://www.zomato.com/shimla/rk-chinese-fast-food-1-sanjauli/info',1,'CafÃ©','11am to 10pm(Mon-Sun)','','NEW','NEW'),('South Corner',150,'South Indian','Shimla','Kasumpti','https://www.zomato.com/shimla/south-corner-kasumpti/info',1,'Bhojanalya','1030am to 10pm(Mon-Sun)','','NEW','NEW'),('Dalziel Restaurant',500,'Cafe','Shimla','Summer Hill','https://www.zomato.com/shimla/dalziel-restaurant-summer-hill/info',1,'CafÃ©','9am to 10pm(Mon-Sun)','Not rated','-','-'),('Heights Restaurant',300,'Bakery,Beverages,Chinese,Coffee,Continental,Desserts,Fast Food,North Indian','Shimla','Kasumpti','https://www.zomato.com/shimla/heights-restaurant-kasumpti/info',1,'Bhojanalya','1030am to 10pm(Mon-Sun)','','NEW','NEW'),('Shimla Bhojnalya',200,'Beverages,Burger,Chinese,Modern Indian,Momos,North Indian,Street Food,Tea','Shimla','Panthaghati','https://www.zomato.com/shimla/shimla-bhojnalya-1-panthaghati/info',2,'Casual Dining','10am to 10pm(Mon-Sun)','','NEW','NEW'),('Dawat Restaurant',0,'Beverages,Fast Food,French,Modern Indian,Mughlai,North Indian','Shimla','Kasumpti','https://www.zomato.com/shimla/dawat-restaurant-kasumpti/info',2,'Bhojanalya','1130am to 10pm(Mon-Sun)','','NEW','NEW'),('Yours Chinese Food',0,'Chinese,Fast Food','Shimla','Sanjauli','https://www.zomato.com/shimla/yours-chinese-food-sanjauli/info',2,'Casual Dining','11am to 10pm(Mon-Sun)','','NEW','NEW'),('Que Express',300,'Bakery,Cafe,Chinese,Ice Cream','Shimla','Summer Hill','https://www.zomato.com/shimla/que-express-summer-hill/info',2,'CafÃ©','1030am to 10pm(Mon-Sun)','','NEW','NEW'),('VIK\'S Kitchen',250,'Afghan,American','Shimla','Kasumpti','https://www.zomato.com/shimla/viks-kitchen-kasumpti/info',2,'Beverage Shop','1030am to 10pm(Mon-Sun)','','NEW','NEW'),('Hotel Crystal Palace',0,'Fast Food,Modern Indian','Shimla','Kasumpti','https://www.zomato.com/shimla/hotel-crystal-palace-kasumpti/info',2,'Beverage Shop','1030am to 1030pm(Mon-Sun)','','NEW','NEW'),('Mid Town Pride',0,'Afghan,Bakery,Chinese','Shimla','Sanjauli','https://www.zomato.com/shimla/mid-town-pride-1-sanjauli/info',2,'CafÃ©','10am to 830pm(Mon-Sun)','','NEW','NEW'),('Twins Corner',200,'Bakery,Desserts,Fast Food','Shimla','Sanjauli','https://www.zomato.com/shimla/twins-corner-sanjauli/info',2,'Bakery','11am to 10pm(Mon-Sun)','','NEW','NEW'),('Sharma Sweets Shop',0,'Mithai,Modern Indian','Shimla','Kasumpti','https://www.zomato.com/shimla/sharma-sweets-shop-kasumpti/info',2,'Fine Dining','10am to 9pm(Mon-Sun)','','NEW','NEW'),('KS Cafe',0,'','Shimla','Kasumpti','https://www.zomato.com/shimla/ks-cafe-kasumpti/info',2,'CafÃ©','10am to 930pm(Mon-Sun)','','NEW','NEW'),('Pizza Hut Delivery',500,'Pizza','Shimla','Summer Hill','https://www.zomato.com/shimla/pizza-hut-delivery-summer-hill/info',2,'Quick Bites','11am to 11pm(Mon-Sun)','Average','3.2','26'),('Shingar Restaurant',500,'North Indian','Shimla','Summer Hill','https://www.zomato.com/shimla/shingar-restaurant-summer-hill/info',2,'Casual Dining','11am to 11pm(Mon-Sun)','Not rated','-','-'),('Agarwal Bhojanalya',500,'Cafe','Shimla','Summer Hill','https://www.zomato.com/shimla/agarwal-bhojanalya-summer-hill/info',2,'CafÃ©','9am to 11pm(Mon-Sun)','Not rated','-','-'),('Bamboo Hut',300,'North Indian,Chinese,Continental','Shimla','Sanjauli','https://www.zomato.com/shimla/bamboo-hut-sanjauli/info',2,'Quick Bites','10am to 11pm(Mon-Sun)','','NEW','NEW');
/*!40000 ALTER TABLE `shimla` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:17
