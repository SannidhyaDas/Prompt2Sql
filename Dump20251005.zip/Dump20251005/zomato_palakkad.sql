-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `palakkad`
--

DROP TABLE IF EXISTS `palakkad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `palakkad` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` text,
  `VOTES` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `palakkad`
--

LOCK TABLES `palakkad` WRITE;
/*!40000 ALTER TABLE `palakkad` DISABLE KEYS */;
INSERT INTO `palakkad` VALUES ('Domino\'s Pizza',600,'Pizza,Fast Food','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/dominos-pizza-vidyut-nagar/info',1,'Quick Bites','11am to 11pm(Mon-Sun)','Average','3.3','98'),('Arabian Grill & Fry',600,'Chinese,Arabian','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/arabian-grill-fry-vidyut-nagar/info',1,'Casual Dining','12noon to 12midnight(Mon-Sun)','Average','3.3','91'),('Aaky\'s Bakehouse',300,'Bakery','Palakkad','Chandranagar Colony','https://www.zomato.com/palakkad/aakys-bakehouse-1-chandranagar-colony/info',1,'Bakery','2pm to 930pm(Mon,Tue,Wed,Fri,Sat,Sun)...','Not rated','-','-'),('Nalanda Rich',600,'North Indian,Chinese,Continental,Kerala,South Indian','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/nalanda-rich-vidyut-nagar/info',1,'Casual Dining','730am to 1030pm(Mon-Sun)','Average','3.3','13'),('London Bakes & Grills',450,'Bakery,Fast Food,Biryani','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/london-bakes-grills-vidyut-nagar/info',1,'Bakery','7am to 11pm(Mon-Sun)','Average','3.2','4'),('The Magik Oven',300,'Bakery','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/the-magik-oven-vidyut-nagar/info',1,'Bakery','11am to 10pm(Mon-Sun)','Average','3.2','6'),('Indian Coffee House',300,'Kerala','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/indian-coffee-house-vidyut-nagar/info',1,'Quick Bites','7am to 10pm(Mon-Sun)','Not rated','-','-'),('Vinayala Sweets and Bakers',200,'Bakery','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/vinayala-sweets-and-bakers-vidyut-nagar/info',1,'Bakery','9am to 10pm(Mon-Sun)','Not rated','-','-'),('Open Kitchen',300,'South Indian,North Indian,Chinese','Palakkad','Puthuppariyaram','https://www.zomato.com/palakkad/open-kitchen-puthuppariyaram/info',1,'Quick Bites','11am to 11pm(Mon-Sun)','Average','3.2','4'),('Hotel Crown',400,'South Indian,North Indian,Chinese,Arabian','Palakkad','Puthuppariyaram','https://www.zomato.com/palakkad/hotel-crown-puthuppariyaram/info',1,'Casual Dining','7am to 11pm(Mon-Sun)','Not rated','-','-'),('Moon City',350,'Kerala','Palakkad','Chandranagar Colony','https://www.zomato.com/palakkad/moon-city-chandranagar-colony/info',1,'Casual Dining','7am to 11pm(Mon-Sun)','Not rated','-','-'),('Jelly And Jam',350,'Kerala,Bakery','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/jelly-and-jam-vidyut-nagar/info',1,'Bakery','930am to 11pm(Mon-Sun)','Not rated','-','-'),('Kanal Restaurant',400,'Kerala,Chinese,North Indian,Seafood','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/kanal-restaurant-vidyut-nagar/info',1,'Quick Bites','8am to 11pm(Mon-Sun)','Not rated','-','-'),('Rockland Multicuisine Restaurant',700,'South Indian,North Indian,Kerala','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/rockland-multicuisine-restaurant-vidyut-nagar/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Not rated','-','-'),('Chillis',400,'South Indian,North Indian,Kerala,Chinese','Palakkad','Nurani','https://www.zomato.com/palakkad/chillis-nurani/info',1,'Casual Dining','12noon to 11pm(Mon-Sun)','Not rated','-','-'),('Shake Abdullah Cafeteria',400,'Arabian,Fast Food,Rolls','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/shake-abdullah-cafeteria-vidyut-nagar/info',2,'Quick Bites','12noon to 11pm(Mon-Sun)','Not rated','-','-'),('Trivandrum Chicken Corner',250,'Kerala','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/trivandrum-chicken-corner-vidyut-nagar/info',2,'Casual Dining','1030am to 1030pm(Mon-Sun)','Not rated','-','-'),('ibaco',300,'Desserts,Ice Cream','Palakkad','Vidyut Nagar','https://www.zomato.com/palakkad/ibaco-vidyut-nagar/info',2,'Dessert Parlor','11am to 11pm(Mon-Sun)','Not rated','-','-');
/*!40000 ALTER TABLE `palakkad` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:17
