-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mussoorie`
--

DROP TABLE IF EXISTS `mussoorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mussoorie` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` double DEFAULT NULL,
  `VOTES` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mussoorie`
--

LOCK TABLES `mussoorie` WRITE;
/*!40000 ALTER TABLE `mussoorie` DISABLE KEYS */;
INSERT INTO `mussoorie` VALUES ('The Glen',700,'Cafe,Turkish','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/the-glen-the-mall-road/info',1,'CafÃ©','12noon to 11pm(Mon-Sun)','Good',3.7,59),('Urban Turban',1000,'North Indian,Mughlai,Momos','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/urban-turban-the-mall-road/info',1,'Casual Dining','11am to 1130pm(Mon-Sun)','Good',3.9,130),('Tunday Kababi',500,'Mughlai','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/tunday-kababi-the-mall-road/info',1,'Quick Bites','11am to 11pm(Mon-Sun)','Average',3.3,43),('The Soy Story',500,'Tibetan,Chinese,Thai,Momos','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/the-soy-story-the-mall-road/info',1,'Quick Bites','1030am to 10pm(Mon-Sun)','Good',3.6,28),('Aap Ka Aahar',600,'North Indian,Mughlai,Chinese','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/aap-ka-aahar-the-mall-road/info',1,'Casual Dining','730am to 1230AM(Mon-Sun)','Average',3.3,9),('Funjabi Tandoorzzz',600,'North Indian,Continental,Chinese','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/funjabi-tandoorzzz-the-mall-road/info',1,'Quick Bites','930am to 11pm(Mon-Sun)','Good',3.5,23),('Doma\'s',500,'Tibetan,Chinese,Momos','Mussoorie','Landour','https://www.zomato.com/mussoorie/domas-landour/info',1,'Casual Dining','11am to 9pm(Mon-Sun)','Good',3.5,27),('Mussoorie Kathi Rolls',300,'Rolls','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/mussoorie-kathi-rolls-the-mall-road/info',1,'Quick Bites','12noon to 130am(Mon-Sun)','Average',3.3,17),('Le Chef',1000,'North Indian,Fast Food,Cafe','Mussoorie','The Mall Road','https://www.zomato.com/mussoorie/le-chef-the-mall-road/info',1,'Casual Dining','930am to 11pm(Mon-Sun)','Average',3.2,18);
/*!40000 ALTER TABLE `mussoorie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:19
