-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zomato
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nainital`
--

DROP TABLE IF EXISTS `nainital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nainital` (
  `NAME` text,
  `PRICE` int DEFAULT NULL,
  `CUSINE_CATEGORY` text,
  `CITY` text,
  `REGION` text,
  `URL` text,
  `PAGE NO` int DEFAULT NULL,
  `CUSINE TYPE` text,
  `TIMING` text,
  `RATING_TYPE` text,
  `RATING` double DEFAULT NULL,
  `VOTES` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nainital`
--

LOCK TABLES `nainital` WRITE;
/*!40000 ALTER TABLE `nainital` DISABLE KEYS */;
INSERT INTO `nainital` VALUES ('Anupam Restaurant',700,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/anupam-restaurant-mall-road/info',1,'Casual Dining','11am to 11pm(Mon-Sun)','Good',3.6,73),('Sweet Home Cuisine Restaurant',350,'North Indian,Chinese,Rolls','Nainital','Tallital','https://www.zomato.com/nainital/sweet-home-cuisine-restaurant-tallital/info',1,'Quick Bites','9am to 1030pm(Mon-Sun)','Average',3.4,40),('Pots & Stones Cafe',1100,'Beverages','Nainital','Mall Road','https://www.zomato.com/nainital/pots-stones-cafe-mall-road/info',1,'CafÃ©','1030am to 1030pm(Mon-Sun)','Good',3.5,72),('New Sher E Punjab',350,'North Indian','Nainital','Tallital','https://www.zomato.com/nainital/new-sher-e-punjab-tallital/info',1,'Casual Dining','10am to 430pm,630pm to 11pm(Mon-Sun)','Average',3.3,27),('Shiva Pure Vegetarian Restaurant',500,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/shiva-pure-vegetarian-restaurant-mall-road/info',1,'Quick Bites','11am to 11pm(Mon-Sun)','Average',3.4,18),('Nanak Restaurant',600,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/nanak-restaurant-mall-road/info',1,'Casual Dining','9am to 5pm,7pm to 1030pm(Mon-Sun)','Average',3.3,26),('The Chocolate Room',700,'Desserts','Nainital','Mall Road','https://www.zomato.com/nainital/the-chocolate-room-mall-road/info',1,'Dessert Parlor','10am to 10pm(Mon-Sun)','Average',3.4,21),('Cafe UK 04',200,'Bakery,Fast Food','Nainital','Ayarpatta','https://www.zomato.com/nainital/cafe-uk-04-ayarpatta/info',1,'Bakery','9am to 10pm(Mon-Sun)','Average',3.3,25),('Al Kareem Restaurant',200,'Mughlai','Nainital','Mall Road','https://www.zomato.com/nainital/al-kareem-restaurant-mall-road/info',1,'Quick Bites','10am to 10pm(Mon-Sun)','Average',3.4,21),('Shiva Restaurant',400,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/shiva-restaurant-mall-road/info',1,'Casual Dining','9am to 1130pm(Mon-Sun)','Average',3.4,10),('Kathi Junction',250,'Rolls','Nainital','Tallital','https://www.zomato.com/nainital/kathi-junction-tallital/info',1,'Quick Bites','10am to 10pm(Mon-Sun)','Average',3.4,12),('The 2nd Wife Restaurant',1000,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/the-2nd-wife-restaurant-mall-road/info',1,'Quick Bites','10am to 11pm(Mon-Sun)','Average',3.3,9),('Dilli Darbaar Dlx',800,'North Indian,Chinese,Mughlai','Nainital','Mall Road','https://www.zomato.com/nainital/dilli-darbaar-dlx-mall-road/info',1,'Casual Dining','12noon to 11pm(Mon-Sun)','Average',3.2,15),('Wow Momos',200,'Fast Food','Nainital','Mall Road','https://www.zomato.com/nainital/wow-momos-mall-road/info',1,'Quick Bites','11am to 10pm(Mon-Sun)','Average',3.4,5),('Mamu\'s Snacks & Bakery',300,'Bakery,Fast Food','Nainital','Mall Road','https://www.zomato.com/nainital/mamus-snacks-bakery-mall-road/info',1,'Bakery','9am to 9pm(Mon-Sun)','Average',3.3,10),('Baker\'s Hut',500,'Bakery,Cafe','Nainital','Ayarpatta','https://www.zomato.com/nainital/bakers-hut-ayarpatta/info',2,'Bakery','7am to 10pm(Mon-Sun)','Average',3.2,19),('Hunger Strike',150,'Fast Food','Nainital','Tallital','https://www.zomato.com/nainital/hunger-strike-tallital/info',2,'Quick Bites','9am to 9pm(Mon-Sun)','Average',3.2,4),('Zaiqa Restaurant',600,'Mughlai,North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/zaiqa-restaurant-mall-road/info',2,'Quick Bites','10am to 4pm,7pm to 10pm(Mon-Sun)','Average',3.4,8),('The Paradise Restaurant',500,'Mughlai,North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/the-paradise-restaurant-mall-road/info',2,'Quick Bites','10am to 5pm,7pm to 10pm(Mon-Sun)','Average',3.2,5),('The Dhaba By Royal Kitchen',600,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/the-dhaba-by-royal-kitchen-mall-road/info',2,'Casual Dining','10am to 11pm(Mon-Tue),10pm to 11pm(Wed-Sun)','Average',3.2,11),('Balaji Vaishnav Bhojnalaya',500,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/balaji-vaishnav-bhojnalaya-mall-road/info',2,'Quick Bites','10am to 10pm(Mon-Sun)','Average',3.2,4),('Embassy Restaurant',600,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/embassy-restaurant-mall-road/info',3,'Casual Dining','9am to 5pm,7pm to 11pm(Mon-Sun)','Average',3.2,12),('Negi Restaurant',500,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/negi-restaurant-mall-road/info',3,'Quick Bites','930am to 1030pm(Mon-Sun)','Average',3.2,7),('Dilli Darbar',500,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/dilli-darbar-mall-road/info',3,'Quick Bites','930am to 12midnight(Mon-Sun)','Average',3.2,6),('Purohit',500,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/purohit-mall-road/info',3,'Casual Dining','9am to 11pm(Mon-Sun)','Average',3.2,6),('Aaban Restaurant',500,'North Indian','Nainital','Mall Road','https://www.zomato.com/nainital/aaban-restaurant-mall-road/info',3,'Quick Bites','10am to 11pm(Mon-Sun)','Average',3.2,5);
/*!40000 ALTER TABLE `nainital` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05 14:38:08
